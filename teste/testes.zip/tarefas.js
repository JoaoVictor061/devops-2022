
const data = [     
    {
        id: 1,
        nome: 'Estudar para a prova',
        categoria: 'Estudos',
        concluido: true,
    },
    {
        id: 2,
        nome: 'Ir à academia',
        categoria: 'Lazer',
        concluido: false,
    },
    {
        id: 3,
        nome: 'Fazer caminhada',
        categoria: 'Lazer',
        concluido: true,
    },
    {
        id: 4,
        nome: 'Realizar prova',
        categoria: 'Estudos',
        concluido: false,
    },
];

function cadastrar(tarefa) {

}

function listar() {
    
}

function listarPorCategoria(categoria) {

}

function listarPorId(id) {
    
}

module.exports = {
    cadastrar,
    listar,
    listarPorId,
    listarPorCategoria
}